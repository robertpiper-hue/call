from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time

# Tiiny.site upload URL
UPLOAD_URL = 'https://tiiny.site/'

# Path to the JSON file
FILE_PATH = 'cashflow2140.json'

# Set up the browser
# Removed headless option to observe browser interactions
options = webdriver.ChromeOptions()
# options.add_argument('--headless')  # Commented out to see the browser
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome driver
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=options)

try:
    # Navigate to Tiiny.site
    driver.get(UPLOAD_URL)

    # Simulate file upload
    upload_button = driver.find_element(By.NAME, 'file')
    upload_button.send_keys(FILE_PATH)

    # Wait for the upload to complete
    time.sleep(5)

    # Submit the form (if necessary)
    submit_button = driver.find_element(By.XPATH, '//button[text()="Upload"]')
    submit_button.click()

    # Wait for the upload to complete
    time.sleep(5)

    # Get the uploaded file URL
    uploaded_url = driver.current_url
    print('File uploaded successfully!')
    print('URL:', uploaded_url)

finally:
    # Close the browser
    driver.quit()
